<?php
    $this->register_app('content', 'Content', 1, 'Default app for managing content', $this->version);
?>