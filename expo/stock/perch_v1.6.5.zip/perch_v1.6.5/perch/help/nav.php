<h3><span><?php echo PerchLang::get('Topics'); ?></span></h3>

<ul>
    <li><a href="<?php echo PERCH_LOGINPATH; ?>/help">Introduction</a></li>
    <li><a href="<?php echo PERCH_LOGINPATH; ?>/help/#getstarted">Editing Content on your website</a></li>
    <li><a href="<?php echo PERCH_LOGINPATH; ?>/help/#regions">Edit a region</a></li>
    <li><a href="<?php echo PERCH_LOGINPATH; ?>/help/#multiple">Regions that allow multiple blocks of content</a></li>
</ul>