<?php

    $users   = $Users->all();

?>