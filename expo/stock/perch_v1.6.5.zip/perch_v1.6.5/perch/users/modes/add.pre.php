<?php

    
    /* --------- New User Form ----------- */

    $fCreateUser 	= new PerchForm('createuser', false);

    $req = array();
    $req['userUsername']   = "Required";
    $req['userGivenName']  = "Required";
    $req['userFamilyName'] = "Required";
    $req['userEmail']      = "Required";
    $req['userPassword']   = "Required";
    $req['userRole']       = "Required";


    $fCreateUser->set_required($req);

    $validation = array();
    $validation['userUsername']	= array("username", PerchLang::get("Username not available, try another."));
    $validation['userEmail']	= array("email", PerchLang::get("Email incomplete or already in use."));

    $fCreateUser->set_validation($validation);

    if ($fCreateUser->posted() && $fCreateUser->validate()) {

		$data		= array();
		$postvars 	= array('userUsername', 'userGivenName', 'userFamilyName','userEmail','userPassword','userRole');
		$data = $fCreateUser->receive($postvars);

		$Users->create($data);

		$Alert->set('success', PerchLang::get('User successfully created.'));

		$fCreateUser->clear();
    }


?>