<?php
    define('PERCH_ERROR_MODE', 'SILENT');
    include('config/config.php');
    include(PERCH_PATH . '/inc/loader.php');
    include('config/apps.php');
?>