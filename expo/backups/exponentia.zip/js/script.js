/* Author: 

*/

$(document).ready(function(){
   var title = jQuery(this).attr('title');
   if(title == 'Expoentia Capital'){
	   var height = $(window).height() - 110;
	   $('.content').css("height", height);
	}   
   
   //alert('jghgj'+ height);		
 });





















